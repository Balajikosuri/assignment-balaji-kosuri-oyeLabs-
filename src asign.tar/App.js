import CoinToss from './components/CoinToss'
import './App.css'

// console.log(fetch(app))

const App = () => <CoinToss />

export default App
