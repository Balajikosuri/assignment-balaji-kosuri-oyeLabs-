const CoinToss = () => <h1>CoinToss</h1>

export default CoinToss
